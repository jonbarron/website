function visualizeTerrain(Z)

surf(Z, visualizeZ(Z), 'EdgeColor', 'none'); imtight; axis image ij; view(-180, 91);

